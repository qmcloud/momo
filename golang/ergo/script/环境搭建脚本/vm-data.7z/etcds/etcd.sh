#!/bin/bash
## author
## Email
## wechat
##### 启动Etcd集群 服务
docker-compose up -d