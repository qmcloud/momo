#!/bin/bash
## author
## Email
## wechat
#####启动nginx （反向代理使用）
docker stop nginx
docker rm nginx
echo "Start Nginx Service..."
docker run -d --name nginx -p 8080:8080 -p 443:443 -v $(pwd)/nginx/conf/nginx.conf:/etc/nginx/conf.d/default.conf -v $(pwd)/nginx/logs:/var/log/nginx nginx
##### 启动mysql 服务
docker stop mysql
docker rm mysql
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=admin -v $(pwd)/mysql8:/var/lib/mysql -d mysql:8.0.21

##### 启动redis 服务
docker stop redis
docker rm redis
echo "Start Redis Service..."
docker run --name redis -d \
  --publish 6379:6379 \
  --env 'REDIS_PASSWORD=admin' \
  --volume $(pwd)/redis:/var/lib/redis \
  sameersbn/redis:latest


### 启动mongodb
docker stop mongo
docker rm mongo
echo "Start Mongodb Service..."
docker run --name mongo -p 27017:27017 -v $(pwd)/mongodb/data:/data/db -v $(pwd)/mongodb/backup:/data/backup -d mongo --auth

## mongodb进入容器创建账号
##docker exec -it mongo mongo admin
#db.createUser({ user: 'jsmith', pwd: 'password', roles: [ { role: "userAdminAnyDatabase", db: "admin" } ] });
#use test;
#db.createUser({user:"testuser",pwd:"testpass",roles:["readWrite"]});
#db.auth("testuser","testpass")

#### 启动elasticsearch 服务
docker stop es
docker rm es
echo "Start Elasticsearch Service..."
docker run -d --name es \
	-p 9200:9200 -p 9300:9300 \
	-e "discovery.type=single-node" \
	-v $(pwd)/elasticsearch:/usr/share/elasticsearch/data \
	spencezhou/elasticsearch:7.6.2