-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: pw
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_menu`
--

DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_menu`
--

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'实时统计','fa-bar-chart','/',NULL,NULL,'2020-08-26 20:38:18'),(2,0,2,'用户管理','fa-tasks',NULL,NULL,NULL,'2020-08-26 20:37:08'),(3,2,3,'Users','fa-users','auth/users',NULL,NULL,NULL),(4,2,4,'Roles','fa-user','auth/roles',NULL,NULL,NULL),(5,2,5,'Permission','fa-ban','auth/permissions',NULL,NULL,NULL),(6,0,6,'后台菜单','fa-bars','auth/menu',NULL,NULL,'2020-08-26 20:39:22'),(7,2,7,'Operation log','fa-history','auth/logs',NULL,NULL,NULL),(8,0,7,'Helpers','fa-gears','',NULL,'2020-08-26 19:49:06','2020-08-26 19:49:06'),(9,8,8,'Scaffold','fa-keyboard-o','helpers/scaffold',NULL,'2020-08-26 19:49:06','2020-08-26 19:49:06'),(10,8,9,'Database terminal','fa-database','helpers/terminal/database',NULL,'2020-08-26 19:49:06','2020-08-26 19:49:06'),(11,8,10,'Laravel artisan','fa-terminal','helpers/terminal/artisan',NULL,'2020-08-26 19:49:06','2020-08-26 19:49:06'),(12,8,11,'Routes','fa-list-alt','helpers/routes',NULL,'2020-08-26 19:49:06','2020-08-26 19:49:06'),(13,0,12,'Scheduling','fa-clock-o','scheduling',NULL,'2020-08-26 19:59:34','2020-08-26 19:59:34'),(14,0,13,'Redis manager','fa-database','redis',NULL,'2020-08-26 20:04:14','2020-08-26 20:04:14'),(15,0,0,'设置','fa-cogs','setting',NULL,'2020-08-26 20:43:40','2020-08-26 20:43:40');
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operation_log`
--

DROP TABLE IF EXISTS `admin_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operation_log`
--

LOCK TABLES `admin_operation_log` WRITE;
/*!40000 ALTER TABLE `admin_operation_log` DISABLE KEYS */;
INSERT INTO `admin_operation_log` VALUES (1,1,'admin','GET','119.122.89.167','[]','2020-08-26 19:31:36','2020-08-26 19:31:36'),(2,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:31:43','2020-08-26 19:31:43'),(3,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:32:11','2020-08-26 19:32:11'),(4,1,'admin/auth/setting','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:32:21','2020-08-26 19:32:21'),(5,1,'admin/auth/setting','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:32:40','2020-08-26 19:32:40'),(6,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:33:10','2020-08-26 19:33:10'),(7,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:34:41','2020-08-26 19:34:41'),(8,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:34:52','2020-08-26 19:34:52'),(9,1,'admin/auth/permissions','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:34:55','2020-08-26 19:34:55'),(10,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:34:59','2020-08-26 19:34:59'),(11,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:35:38','2020-08-26 19:35:38'),(12,1,'admin/auth/setting','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:35:54','2020-08-26 19:35:54'),(13,1,'admin/auth/setting','GET','119.122.89.167','[]','2020-08-26 19:42:59','2020-08-26 19:42:59'),(14,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:43:07','2020-08-26 19:43:07'),(15,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:43:11','2020-08-26 19:43:11'),(16,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:43:15','2020-08-26 19:43:15'),(17,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 19:43:17','2020-08-26 19:43:17'),(18,1,'admin/auth/users','GET','119.122.89.167','[]','2020-08-26 19:43:25','2020-08-26 19:43:25'),(19,1,'admin/auth/users','GET','119.122.89.167','[]','2020-08-26 19:49:48','2020-08-26 19:49:48'),(20,1,'admin/auth/logout','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:09:36','2020-08-26 20:09:36'),(21,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:11:44','2020-08-26 20:11:44'),(22,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:19:40','2020-08-26 20:19:40'),(23,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:19:41','2020-08-26 20:19:41'),(24,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:19:41','2020-08-26 20:19:41'),(25,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:19:49','2020-08-26 20:19:49'),(26,1,'admin/helpers/scaffold','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:19:58','2020-08-26 20:19:58'),(27,1,'admin/helpers/terminal/database','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:20:10','2020-08-26 20:20:10'),(28,1,'admin/helpers/terminal/artisan','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:20:13','2020-08-26 20:20:13'),(29,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:20:39','2020-08-26 20:20:39'),(30,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:20:44','2020-08-26 20:20:44'),(31,1,'admin/auth/permissions','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:20:46','2020-08-26 20:20:46'),(32,1,'admin/helpers/routes','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:20:49','2020-08-26 20:20:49'),(33,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:21:09','2020-08-26 20:21:09'),(34,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:21:35','2020-08-26 20:21:35'),(35,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:21:38','2020-08-26 20:21:38'),(36,1,'admin/auth/permissions','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:21:40','2020-08-26 20:21:40'),(37,1,'admin/helpers/routes','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:21:43','2020-08-26 20:21:43'),(38,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:22:23','2020-08-26 20:22:23'),(39,1,'admin/auth/logout','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:22:26','2020-08-26 20:22:26'),(40,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:23:22','2020-08-26 20:23:22'),(41,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:24:01','2020-08-26 20:24:01'),(42,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:24:13','2020-08-26 20:24:13'),(43,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:24:14','2020-08-26 20:24:14'),(44,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:24:21','2020-08-26 20:24:21'),(45,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:24:26','2020-08-26 20:24:26'),(46,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:24:26','2020-08-26 20:24:26'),(47,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:25:12','2020-08-26 20:25:12'),(48,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:25:12','2020-08-26 20:25:12'),(49,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:20','2020-08-26 20:28:20'),(50,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:28:20','2020-08-26 20:28:20'),(51,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:22','2020-08-26 20:28:22'),(52,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:28:22','2020-08-26 20:28:22'),(53,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:23','2020-08-26 20:28:23'),(54,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:28:23','2020-08-26 20:28:23'),(55,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:24','2020-08-26 20:28:24'),(56,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:28:24','2020-08-26 20:28:24'),(57,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:26','2020-08-26 20:28:26'),(58,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:28:26','2020-08-26 20:28:26'),(59,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:29','2020-08-26 20:28:29'),(60,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:28:29','2020-08-26 20:28:29'),(61,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:34','2020-08-26 20:28:34'),(62,1,'admin/auth/menu/14/edit','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:28:44','2020-08-26 20:28:44'),(63,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:01','2020-08-26 20:29:01'),(64,1,'admin','GET','119.122.89.167','[]','2020-08-26 20:29:16','2020-08-26 20:29:16'),(65,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:28','2020-08-26 20:29:28'),(66,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:31','2020-08-26 20:29:31'),(67,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:33','2020-08-26 20:29:33'),(68,1,'admin/auth/permissions','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:36','2020-08-26 20:29:36'),(69,1,'admin/auth/permissions/create','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:39','2020-08-26 20:29:39'),(70,1,'admin/auth/permissions','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:47','2020-08-26 20:29:47'),(71,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:56','2020-08-26 20:29:56'),(72,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:57','2020-08-26 20:29:57'),(73,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:58','2020-08-26 20:29:58'),(74,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:29:59','2020-08-26 20:29:59'),(75,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:00','2020-08-26 20:30:00'),(76,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:01','2020-08-26 20:30:01'),(77,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:02','2020-08-26 20:30:02'),(78,1,'admin/scheduling','GET','119.122.89.167','[]','2020-08-26 20:30:02','2020-08-26 20:30:02'),(79,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:06','2020-08-26 20:30:06'),(80,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:09','2020-08-26 20:30:09'),(81,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:30:09','2020-08-26 20:30:09'),(82,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:23','2020-08-26 20:30:23'),(83,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:30:24','2020-08-26 20:30:24'),(84,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:25','2020-08-26 20:30:25'),(85,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:30:25','2020-08-26 20:30:25'),(86,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:30:28','2020-08-26 20:30:28'),(87,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:30:28','2020-08-26 20:30:28'),(88,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:31:02','2020-08-26 20:31:02'),(89,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:31:04','2020-08-26 20:31:04'),(90,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:31:04','2020-08-26 20:31:04'),(91,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:31:11','2020-08-26 20:31:11'),(92,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:31:11','2020-08-26 20:31:11'),(93,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:31:22','2020-08-26 20:31:22'),(94,1,'admin/helpers/terminal/artisan','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:31:38','2020-08-26 20:31:38'),(95,1,'admin/helpers/scaffold','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:31:40','2020-08-26 20:31:40'),(96,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:35:55','2020-08-26 20:35:55'),(97,1,'admin/auth/menu/2/edit','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:36:01','2020-08-26 20:36:01'),(98,1,'admin/auth/menu/2','PUT','119.122.89.167','{\"parent_id\":\"0\",\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"fa-tasks\",\"uri\":null,\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"anai6xheX51xjmCeawbcpCsvOu3ucif9hBvi4byG\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/live.52webrtc.top\\/admin\\/auth\\/menu\"}','2020-08-26 20:37:08','2020-08-26 20:37:08'),(99,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:37:08','2020-08-26 20:37:08'),(100,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:37:12','2020-08-26 20:37:12'),(101,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:37:18','2020-08-26 20:37:18'),(102,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:37:21','2020-08-26 20:37:21'),(103,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:37:23','2020-08-26 20:37:23'),(104,1,'admin/auth/menu/1/edit','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:37:33','2020-08-26 20:37:33'),(105,1,'admin/auth/menu/1','PUT','119.122.89.167','{\"parent_id\":\"0\",\"title\":\"\\u5b9e\\u65f6\\u7edf\\u8ba1\",\"icon\":\"fa-bar-chart\",\"uri\":\"\\/\",\"roles\":[null],\"permission\":null,\"_token\":\"anai6xheX51xjmCeawbcpCsvOu3ucif9hBvi4byG\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/live.52webrtc.top\\/admin\\/auth\\/menu\"}','2020-08-26 20:38:18','2020-08-26 20:38:18'),(106,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:38:18','2020-08-26 20:38:18'),(107,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:38:23','2020-08-26 20:38:23'),(108,1,'admin/redis','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:38:39','2020-08-26 20:38:39'),(109,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:38:39','2020-08-26 20:38:39'),(110,1,'admin/scheduling','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:38:45','2020-08-26 20:38:45'),(111,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:38:48','2020-08-26 20:38:48'),(112,1,'admin/auth/menu/6/edit','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:39:11','2020-08-26 20:39:11'),(113,1,'admin/auth/menu/6','PUT','119.122.89.167','{\"parent_id\":\"0\",\"title\":\"\\u540e\\u53f0\\u83dc\\u5355\",\"icon\":\"fa-bars\",\"uri\":\"auth\\/menu\",\"roles\":[null],\"permission\":null,\"_token\":\"anai6xheX51xjmCeawbcpCsvOu3ucif9hBvi4byG\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/live.52webrtc.top\\/admin\\/auth\\/menu\"}','2020-08-26 20:39:22','2020-08-26 20:39:22'),(114,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:39:22','2020-08-26 20:39:22'),(115,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:39:24','2020-08-26 20:39:24'),(116,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:39:29','2020-08-26 20:39:29'),(117,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:39:31','2020-08-26 20:39:31'),(118,1,'admin/auth/setting','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:39:49','2020-08-26 20:39:49'),(119,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:39:49','2020-08-26 20:39:49'),(120,1,'admin/auth/setting','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:40:30','2020-08-26 20:40:30'),(121,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:40:56','2020-08-26 20:40:56'),(122,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:40:59','2020-08-26 20:40:59'),(123,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:01','2020-08-26 20:41:01'),(124,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:03','2020-08-26 20:41:03'),(125,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:04','2020-08-26 20:41:04'),(126,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:08','2020-08-26 20:41:08'),(127,1,'admin/auth/users/1/edit','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:21','2020-08-26 20:41:21'),(128,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:36','2020-08-26 20:41:36'),(129,1,'admin/auth/users/create','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:40','2020-08-26 20:41:40'),(130,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:48','2020-08-26 20:41:48'),(131,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:51','2020-08-26 20:41:51'),(132,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:53','2020-08-26 20:41:53'),(133,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:56','2020-08-26 20:41:56'),(134,1,'admin/auth/permissions','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:41:56','2020-08-26 20:41:56'),(135,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:42:19','2020-08-26 20:42:19'),(136,1,'admin/auth/menu','POST','119.122.89.167','{\"parent_id\":\"0\",\"title\":\"\\u8bbe\\u7f6e\",\"icon\":\"fa-cogs\",\"uri\":\"setting\",\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"anai6xheX51xjmCeawbcpCsvOu3ucif9hBvi4byG\"}','2020-08-26 20:43:40','2020-08-26 20:43:40'),(137,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:43:40','2020-08-26 20:43:40'),(138,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:43:47','2020-08-26 20:43:47'),(139,1,'admin/auth/menu','GET','119.122.89.167','[]','2020-08-26 20:43:50','2020-08-26 20:43:50'),(140,1,'admin','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:55:18','2020-08-26 20:55:18'),(141,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:55:23','2020-08-26 20:55:23'),(142,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:55:38','2020-08-26 20:55:38'),(143,1,'admin/auth/users/create','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:55:54','2020-08-26 20:55:54'),(144,1,'admin/auth/users','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:56:00','2020-08-26 20:56:00'),(145,1,'admin/auth/roles','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:56:00','2020-08-26 20:56:00'),(146,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:56:02','2020-08-26 20:56:02'),(147,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:56:04','2020-08-26 20:56:04'),(148,1,'admin/auth/menu','GET','119.122.89.167','{\"_pjax\":\"#pjax-container\"}','2020-08-26 20:56:25','2020-08-26 20:56:25');
/*!40000 ALTER TABLE `admin_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_name_unique` (`name`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions`
--

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'All permission','*','','*',NULL,NULL),(2,'Dashboard','dashboard','GET','/',NULL,NULL),(3,'Login','auth.login','','/auth/login\r\n/auth/logout',NULL,NULL),(4,'User setting','auth.setting','GET,PUT','/auth/setting',NULL,NULL),(5,'Auth management','auth.management','','/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs',NULL,NULL),(6,'Admin helpers','ext.helpers','','/helpers/*','2020-08-26 19:49:06','2020-08-26 19:49:06'),(7,'Scheduling','ext.scheduling','','/scheduling*','2020-08-26 19:59:34','2020-08-26 19:59:34'),(8,'Redis Manager','ext.redis-manager','','/redis*','2020-08-26 20:04:14','2020-08-26 20:04:14');
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_menu`
--

DROP TABLE IF EXISTS `admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_menu`
--

LOCK TABLES `admin_role_menu` WRITE;
/*!40000 ALTER TABLE `admin_role_menu` DISABLE KEYS */;
INSERT INTO `admin_role_menu` VALUES (1,2,NULL,NULL),(1,15,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
INSERT INTO `admin_role_permissions` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_users`
--

DROP TABLE IF EXISTS `admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_users`
--

LOCK TABLES `admin_role_users` WRITE;
/*!40000 ALTER TABLE `admin_role_users` DISABLE KEYS */;
INSERT INTO `admin_role_users` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Administrator','administrator','2020-08-26 19:21:00','2020-08-26 19:21:00');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_user_permissions`
--

DROP TABLE IF EXISTS `admin_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user_permissions`
--

LOCK TABLES `admin_user_permissions` WRITE;
/*!40000 ALTER TABLE `admin_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$19F66c51umxJO0bfgDg41.wr4gFtJFTm0v8NaSyTWQdKzBpH2piwq','Administrator',NULL,'ZpzpMA1FxuAxv8XojVinZGgErjUCtLy5EOFxaSrDu0FuKf36FcVu7sWWzpsC','2020-08-26 19:21:00','2020-08-26 19:21:00');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2019_08_19_000000_create_failed_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-27 12:57:44
