# SelectPage
FastAdmin动态下载列表模块

## 使用方法
http://doc.fastadmin.net/docs/component.html

## 特别感谢
https://github.com/TerryZ/SelectPage